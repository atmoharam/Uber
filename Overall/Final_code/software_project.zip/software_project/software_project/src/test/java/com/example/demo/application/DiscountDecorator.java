package com.example.demo.application;

public abstract class DiscountDecorator extends Discount {
    public abstract double getPrice ( );
}
