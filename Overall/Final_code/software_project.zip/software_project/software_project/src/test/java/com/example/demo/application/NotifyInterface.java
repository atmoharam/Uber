package com.example.demo.application;

import com.example.demo.core.Ride;

import java.util.ArrayList;

public interface NotifyInterface {
     ArrayList<Ride> notify( ArrayList<String>drivers ,String driverId);
}
